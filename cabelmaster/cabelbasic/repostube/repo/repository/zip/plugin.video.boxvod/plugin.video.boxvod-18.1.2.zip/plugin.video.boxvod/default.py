#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmcplugin,xbmcgui,urllib,sys,re,os,urlparse,urllib2

addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
icon1=xbmc.translatePath('special://home/addons/'+addonID+'/xstream.png')
icon2=xbmc.translatePath('special://home/addons/'+addonID+'/doku.png')
icon4=xbmc.translatePath('special://home/addons/'+addonID+'/ilr.png')
icon5=xbmc.translatePath('special://home/addons/'+addonID+'/music.png')
icon6=xbmc.translatePath('special://home/addons/'+addonID+'/you.png')
icon7=xbmc.translatePath('special://home/addons/'+addonID+'/tvnow.png')
icon8=xbmc.translatePath('special://home/addons/'+addonID+'/line5.png')
icon9=xbmc.translatePath('special://home/addons/'+addonID+'/line4.png')
icon10=xbmc.translatePath('special://home/addons/'+addonID+'/line3.png')
icon11=xbmc.translatePath('special://home/addons/'+addonID+'/line2.png')
icon12=xbmc.translatePath('special://home/addons/'+addonID+'/line1.png')


def index():
    addDir("BOX.VOD.1","plugin://plugin.video.xtream-codes1/?action=detect_modification&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Video%20On%20Demand&amp;url",icon12)
    addDir("BOX.VOD.2","plugin://plugin.video.xtream-codes2/?action=detect_modification&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Video%20On%20Demand&amp;url",icon11)
    addDir("BOX.VOD.3","plugin://plugin.video.xtream-codes3/?action=detect_modification&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Video%20On%20Demand&amp;url",icon10)
    addDir("BOX.VOD.4","plugin://plugin.video.xtream-codes4/?action=detect_modification&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Video%20On%20Demand&amp;url",icon9)
    addDir("BOX.VOD.5","plugin://plugin.video.xtream-codes5/?action=detect_modification&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Video%20On%20Demand&amp;url",icon8)
    #addDir("BOX.SERIEN","plugin://plugin.video.box.portal/?action=list_series&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Series&amp;url",icon11)
    #addDir("STUBE.PORTAL","plugin://plugin.video.StubeTV",icon8)
    #addDir("X.STREAM","plugin://plugin.video.xstream",icon1)
    #addDir("DISNEY+","plugin://slyguy.disney.plus",icon10)
    #addDir("TV.NOW","plugin://plugin.video.tvnow.de",icon7)
    #addDir("I.LOVE.RADIO","plugin://plugin.audio.iloveradio",icon4)
    #addDir("MICLIER.DOKU","plugin://plugin.video.miclier-doku?sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%2Fplugin.video.miclier-doku%2Fresources%2Ffanart.jpg%26meta%3Dlabel%253D%25255BCOLORgreen%25255DMICLIER%25255B%25252FCOLOR%25255D-DOKU%26desc%3DDoku+Kan%C3%A4le+auf+Youtube+Terra+X%2CZDF+Histroy%2CArte%2CN24+usw+.%26_options_sf",icon2)
    #addDir("ALL.KINDS.OF.MUSIC","plugin://plugin.video.All.Kinds.of.Music",icon5)
    #addDir("TIDE","plugin://plugin.video.tide",icon9)
    #addDir("YOU.TUBE","plugin://plugin.video.youtube",icon6)

   

    xbmcplugin.endOfDirectory(pluginhandle)
    
    
    
def addDir(name,url,iconimage):
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image',iconimage)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    return ok


def translation(id):
    return addon.getLocalizedString(id).encode('utf-8')


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

index()
