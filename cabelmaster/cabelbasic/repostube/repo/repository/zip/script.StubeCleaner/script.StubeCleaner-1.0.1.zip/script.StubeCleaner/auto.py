##########################################
#  `7MM"""YMM MMP""MM""YMM   .g8"""bgd   #
#    MM    `7 P'   MM   `7 .dP'     `M   #
#    MM   d        MM      dM'       `   #
#    MM""MM        MM      MM            #
#    MM   Y        MM      MM.    `7MMF' #
#    MM            MM      `Mb.     MM   #
#  .JMML.        .JMML.      `"bmmmdPY   #
########################################## 


import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
from datetime import date, datetime, timedelta
from resources.libs import source,windows,speedtest, addonwindow as pyxbmct



AUTOCLEANUP    = source.getS('autoclean')
AUTOCACHE      = source.getS('clearcache')
AUTOPACKAGES   = source.getS('clearpackages')
AUTOTHUMBS     = source.getS('clearthumbs')
AUTOFEQ        = source.getS('autocleanfeq')
AUTONEXTRUN    = source.getS('nextautocleanup')
FIRSTRUN       = source.getS('firstruncheck')
MANUALMODE     = source.getS('manclean')
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 0
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)


if FIRSTRUN == '':
		source.log("[First Run Check] First Run", xbmc.LOGNOTICE)
		windows.firstRun()
		xbmc.sleep(500)
		source.setS('firstruncheck', 'Done')


source.log("[Manual Maintenance] Started", xbmc.LOGNOTICE)
if MANUALMODE == 'true':
	filesize = int(source.getS('filesize_alert'))
	filesize_thumb = int(source.getS('filesizethumb_alert'))
	total_size2 = 0
	total_size = 0
	count = 0
	total_sizetext2 = "%.0f" % (total_size2/1024000.0)
	
	for dirpath, dirnames, filenames in os.walk(PACKAGES):
		count = 0
		for f in filenames:
			count += 1
			fp = os.path.join(dirpath, f)
			total_size += os.path.getsize(fp)
	total_sizetext = "%.0f" % (total_size/1024000.0)
		
	if int(total_sizetext) > filesize:
		source.clearPackagesStart(); source.refresh()
		source.log("[Auto Cleaner] Package Cleaner Triggered", xbmc.LOGNOTICE)
		
	for dirpath2, dirnames2, filenames2 in os.walk(THUMBS):
		for f2 in filenames2:
			fp2 = os.path.join(dirpath2, f2)
			total_size2 += os.path.getsize(fp2)
	total_sizetext2 = "%.0f" % (total_size2/1024000.0)
	
	if int(total_sizetext2) > filesize_thumb:
		source.clearThumb(); source.refresh()
		source.log("[Auto Cleaner] Thumbs Cleaner Triggered", xbmc.LOGNOTICE)
	
	if source.getS('clearcache') == 'true':
		source.clearCache(); source.refresh()
		source.log("[Auto Cleaner] Thumbs Cleaner Triggered", xbmc.LOGNOTICE)
else: source.log("[Manual Maintenance] Not Enabled", xbmc.LOGNOTICE)



source.log("[Auto Clean Up] Started", xbmc.LOGNOTICE)
if AUTOCLEANUP == 'true':
	service = False
	days = [TODAY, TOMORROW, THREEDAYS, ONEWEEK]
	feq = int(float(AUTOFEQ))
	if AUTONEXTRUN <= str(TODAY) or feq == 0:
		service = True
		next_run = days[feq]
		source.setS('nextautocleanup', str(next_run))
	else: source.log("[Auto Clean Up] Next Clean Up %s" % AUTONEXTRUN, xbmc.LOGNOTICE)
	if service == True:
		AUTOCACHE      = source.getS('clearcache')
		AUTOPACKAGES   = source.getS('clearpackages')
		AUTOTHUMBS     = source.getS('clearthumbs')
		if AUTOCACHE == 'true': source.log('[Auto Clean Up] Cache: On', xbmc.LOGNOTICE); source.clearCache(True)
		else: source.log('[Auto Clean Up] Cache: Off', xbmc.LOGNOTICE)
		if AUTOTHUMBS == 'true': source.log('[Auto Clean Up] Old Thumbs: On', xbmc.LOGNOTICE); source.oldThumbs()
		else: source.log('[Auto Clean Up] Old Thumbs: Off', xbmc.LOGNOTICE)
		if AUTOPACKAGES == 'true': source.log('[Auto Clean Up] Packages: On', xbmc.LOGNOTICE); source.clearPackagesStartup()
		else: source.log('[Auto Clean Up] Packages: Off', xbmc.LOGNOTICE)
else: source.log('[Auto Clean Up] Turned off', xbmc.LOGNOTICE)
