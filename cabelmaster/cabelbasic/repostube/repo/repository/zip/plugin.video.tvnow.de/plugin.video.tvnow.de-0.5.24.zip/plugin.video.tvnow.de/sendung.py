class Sendung():
    def __init__(self, sid, title, station, tGroup):
        self.sid = sid
        self.title = title
        self.station = station
        self.tGroup = tGroup