#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def get_youtube_live_stream(channel_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

#-------------------#
#set_view_mode('50')
set_content('movies')
#-----------------------------------------------------------------------------------------------#


add_item('Terra X',get_youtube_playlist('PLikmWKyGm7w4PQMbunBvj0PiafEgRzKLJ'),os.path.join(addon_path,'resources','icons','terrax.jpeg'),'Terra X | ganze Sendungen',is_folder=True)
add_item('Terra X II',get_youtube_playlist('PLg-rKdrKbDtlX-Alj0pyJ8BV2UUcU0yEZ'),os.path.join(addon_path,'resources','icons','terrax2.jpeg'),'Terra X | ganze Sendungen',is_folder=True)
add_item('ZDF-History',get_youtube_playlist('PLtgw6t2VdpFa-EQZiCCu0eQtKPokLCavG'),os.path.join(addon_path,'resources','icons','zdfh.jpeg'),'ZDF-History mit über 200 Folgen .',is_folder=True)
add_item('N24 Doku',get_youtube_playlist('PLLKmPm7DWMTk7DecizEnA14FR6Ukk1RtP'),os.path.join(addon_path,'resources','icons','n24d.jpg'),' N24 Dokus  200 Folgen.',is_folder=True)
add_item('ARTE- History ',get_youtube_playlist('PL-t786AQxGO_7Rt3_4O01qKZXm6D-G-Od'),os.path.join(addon_path,'resources','icons','arteh.png'),'ARTE ] History  über 200 Folgen.',is_folder=True)
add_item('ARTE- Dokus und Reportagen ',get_youtube_playlist('PLlQWnS27jXh846YQxXL9VeyoU47xCAmpY'),os.path.join(addon_path,'resources','icons','arte.jpg'),'Dokus und Reportagen | ARTE über 450 Folgen.',is_folder=True)
add_item('Dokustreams',get_youtube_playlist('PLikmWKyGm7w68KLLD6Vx3brMDnEqwiUHK'),os.path.join(addon_path,'resources','icons','dokustreams.jpg'),'Dokustreams.de | über 800 ganze Sendungen',is_folder=True)
add_item('Alpha Centauri',get_youtube_playlist('PLikmWKyGm7w4foHDk9XjMc7udzX-lS9ir'),os.path.join(addon_path,'resources','icons','centauri.jpeg'),'Astrophysik mit Harald Lesch',is_folder=True)
add_item('MAYDAY -Alarm Im Cockpit',get_youtube_playlist('PLXzwYRS8o0P1HRismRrNh5Z2wzWpYYyWL'),os.path.join(addon_path,'resources','icons','mayday.jpg'),'Dokuseure mit 66 Folgen.',is_folder=True)
add_item('Crime Dokus',get_youtube_playlist('PL8vy1Dmnedmpjwe51g22ts-GjhKYeqnL1'),os.path.join(addon_path,'resources','icons','crime.jpg'),'Crime Dokus mit über 1100 Folgen .',is_folder=True)
add_item('Dokus Kriminalfälle',get_youtube_playlist('PLD9tXDfn3aaOiQsMHzpPQK3fVBtYqo5Hl'),os.path.join(addon_path,'resources','icons','crime3.jpg'),'Dokus Kriminalfälle über 1900 Crime Folgen.',is_folder=True)
add_item('Mord Dokus',get_youtube_playlist('PL71TJK-M7RX27K06Bj2-bEDNUiPRU_dPG'),os.path.join(addon_path,'resources','icons','crime2.jpg'),' Mord Dokus  65 Folgen.',is_folder=True)
add_item('Ganster Dokus',get_youtube_playlist('PLk9HPyqc6AILC4JrdbTCWRp5jNJqLx4kg'),os.path.join(addon_path,'resources','icons','gang.jpg'),' Gangster und Gangs.',is_folder=True)
add_item('Universum Dokumentationen',get_youtube_playlist('PLybSgyzzjOmk0GXvMkEW0PPiVPUvs3Rgg'),os.path.join(addon_path,'resources','icons','universe.jpg'),'Universum Dokumentationen über 200 Folgen .',is_folder=True)
add_item('DOKU // Physik // Science // Technik // Raumfahrt',get_youtube_playlist('PLEs1C_0f4i7-Y9fQbGjHqxhm6oRMerEEx'),os.path.join(addon_path,'resources','icons','physik.jpg'),'DOKU // Physik // Science // Technik // Raumfahrt über 300 Crime Folgen.',is_folder=True)
add_item('Geschichte, chronologisch',get_youtube_playlist('PLCmAcRSgj3IQy579zESYlbuEUn0UILucl'),os.path.join(addon_path,'resources','icons','history.jpg'),'Geschichte, chronologisch über 400 Folgen',is_folder=True)
add_item('Natur- und Tierdokumentationen',get_youtube_playlist('PL4d-w5KrJjTZZxEb0XKIKLLkZbdWK5iJn'),os.path.join(addon_path,'resources','icons','wild5.jpg'),'Fast 200 Folgen Natur- und Tierdokumentationen . ',is_folder=True)
add_item('Tier Dokus Anna, Paula und die wilden Tiere ',get_youtube_playlist('PLydq0NtegKH-KFQMy20gfaS4Wee80zCkv'),os.path.join(addon_path,'resources','icons','anna.jpeg'),'ARTE ] Anna, Paula und die wilden Tiere  über 143 Folgen.',is_folder=True)
add_item('Tierdokumentationen ',get_youtube_playlist('PLOtxwk6mlZ-vOwYSa_EZgtF_6Xs9QrNXm'),os.path.join(addon_path,'resources','icons','wild12.jpg'),'Tierdokumentationen (Tierfilme, Dokus über Tiere & Natur, Naturfilme) 100 Folgen.',is_folder=True)
add_item('Doku-Das Dritte Reich',get_youtube_playlist('PLWCh1VrmvgDmxqpmRyslpSzE1XucQ63lO'),os.path.join(addon_path,'resources','icons','reich.jpg'),'Doku- Das Dritte Reich 109 Folgen.',is_folder=True)
add_item('Doku-2.Weltkrieg 1',get_youtube_playlist('PLPdh1srUHkHMBSQSyoCxRX_Tft7UPtZKI'),os.path.join(addon_path,'resources','icons','wwt.jpg'),'Doku-2.Weltkrieg mehr als 60 Folgen.',is_folder=True)
add_item('Doku-2.Weltkrieg 2',get_youtube_playlist('PLB5Igv7tds-k1Z55IIM94K9eUoIsPlgBF'),os.path.join(addon_path,'resources','icons','wwt.jpg'),'Doku-2.Weltkrieg mehr als 70 Folgen.',is_folder=True)
add_item('Doku-2.Weltkrieg 3',get_youtube_playlist('PLas7oA026StNicIR-pGRDTbLC9w-i9KMh'),os.path.join(addon_path,'resources','icons','wwt.jpg'),'Doku-2.Weltkrieg mehr als 30 Folgen. ',is_folder=True)
add_item('Legendäre Schlachten',get_youtube_playlist('PLexOauvOy9YExEsobKvMOXRN8Q1MmymjT'),os.path.join(addon_path,'resources','icons','schlacht.jpg'),'Legendäre Schlachten 30 Folgen.',is_folder=True)
add_item('Kriegsfilme  ',get_youtube_playlist('PLsGK3aH9-P9koGCe60moCG4P3Y3SXEwAM'),os.path.join(addon_path,'resources','icons','war.jpg'),' 37 Filme.',is_folder=True)
add_item('Tauchen',get_youtube_playlist('PL34ba0YZpTzq9ybHk8OOH1RMxnsxm8Lvq'),os.path.join(addon_path,'resources','icons','tauchen.jpg'),'Tauchen über 80 Folgen.',is_folder=True)
add_item('Unterwasser Doku 1.',get_youtube_playlist('PLsGK3aH9-P9kICi2pgw6ygjBgBCZioT83'),os.path.join(addon_path,'resources','icons','tauchen2.jpg'),'Tauchen ect.',is_folder=True)
add_item('Unterwasser Doku 2.',get_youtube_playlist('PLi1BIRwUIrR0HX0zhHiHIErpDRLWAtkpC'),os.path.join(addon_path,'resources','icons','tauchen2.jpg'),'Unterwasser Doku 37 Folgen.',is_folder=True)


	
#-----------------------------------------------------------------------------------------------#

set_end_of_directory()