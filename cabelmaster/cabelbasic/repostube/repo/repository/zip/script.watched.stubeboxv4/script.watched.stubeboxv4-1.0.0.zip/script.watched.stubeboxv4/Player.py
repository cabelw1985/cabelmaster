 # -*- coding: utf-8 -*- 

import base64, codecs
import xbmcaddon

MainBase = base64.b64decode('aHR0cDovL3N0dWJlYm94LnN0dWJlLm9yZy9zdGJ2NC9tZW51LnhtbA==')
addon = xbmcaddon.Addon('script.watched.stubeboxv4')