#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmcplugin,xbmcgui,urllib,sys,re,os,urlparse,urllib2

addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
#icon1=xbmc.translatePath('special://home/addons/'+addonID+'/vawatched.png')
#icon2=xbmc.translatePath('special://home/addons/'+addonID+'/doku.png')
#icon4=xbmc.translatePath('special://home/addons/'+addonID+'/fp.png')
#icon5=xbmc.translatePath('special://home/addons/'+addonID+'/ddl.png')
icon10=xbmc.translatePath('special://home/addons/'+addonID+'/vod2.png')
icon7=xbmc.translatePath('special://home/addons/'+addonID+'/vod5.png')
icon8=xbmc.translatePath('special://home/addons/'+addonID+'/vod4.png')
icon9=xbmc.translatePath('special://home/addons/'+addonID+'/vod3.png')
icon11=xbmc.translatePath('special://home/addons/'+addonID+'/vod1.png')
icon16=xbmc.translatePath('special://home/addons/'+addonID+'/vod6.png')
icon17=xbmc.translatePath('special://home/addons/'+addonID+'/vod7.png')
icon18=xbmc.translatePath('special://home/addons/'+addonID+'/vod8.png')
icon19=xbmc.translatePath('special://home/addons/'+addonID+'/vod9.png')
icon20=xbmc.translatePath('special://home/addons/'+addonID+'/vod10.png')



def index():
    addDir("BOX.IPTV.1","plugin://plugin.video.xtream-codes1/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon11)
    addDir("BOX.IPTV.2","plugin://plugin.video.xtream-codes2/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon10)
    addDir("BOX.IPTV.3","plugin://plugin.video.xtream-codes3/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon9)
    addDir("BOX.IPTV.4","plugin://plugin.video.xtream-codes4/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon8)
    addDir("BOX.IPTV.5","plugin://plugin.video.xtream-codes5/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon7)
    addDir("BOX.IPTV.6","plugin://plugin.video.xtream-codes6/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon16)
    addDir("BOX.IPTV.7","plugin://plugin.video.xtream-codes7/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon17)
    addDir("BOX.IPTV.8","plugin://plugin.video.xtream-codes8/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon18)
    addDir("BOX.IPTV.9","plugin://plugin.video.xtream-codes9/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon19)
    addDir("BOX.IPTV.10","plugin://plugin.video.xtream-codes10/?action=security_check&amp;extra&amp;page&amp;plot&amp;thumbnail&amp;title=Live%20TV&amp;url",icon20)

        #addDir("VAVOO.WATCHED","plugin://plugin.video.vawatched",icon1)
    #addDir("STALKER.TV","plugin://plugin.program.super.favourites/?cmd=ActivateWindow(TvChannels)&content_type&image=special%3a%2f%2fhome%2faddons%2fskin.stubeboxv4%2fmedia%2ficons%2fstb.png&label=%5bCOLOR%20ghostwhite%5dSTALKER%20%20LIVE%20TV%5b%2fCOLOR%5d&mode=650",icon7)
    #addDir("STUBE.TV","plugin://script.watched.stubeboxv4/?fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2fstube.box.v4%2ffiles%2f.kodi%2faddons%2fscript.watched.stubeboxv4%2ffanart.jpg&amp;mode=53&amp;name=STUBE%20TV&amp;url=plugin%3a%2f%2fscript.watched.stubeboxv4%2f%3ffanart%26mode%3d53%26name%3d%255bB%255d%255bCOLOR%2520red%255dStube%2520%255bCOLOR%2520skyblue%255dTV%2520%2520%255bCOLOR%2520white%255d%2520LiveTV%255b%252fCOLOR%255d%255b%252fB%255d%2520%26url%3dplugin%253a%252f%252fplugin.video.StubeTV%252f%253furl%253dhttp%25253A%25252F%25252Frepo.stube.org%25252Ftvlist%25252Fnew_menu.xml%2526mode%253d1%2526name%253d%25255BB%25255D%25255BCOLOR%252bred%25255DStube%252b%25255BCOLOR%252bskyblue%25255DTV%252b%252b%25255BCOLOR%252bwhite%25255D%252bLiveTV%25255B%25252FCOLOR%25255D%25255B%25252FB%25255D%252b%2526fanart%253d",icon8)
    #addDir("MICLIER.DOKU","plugin://plugin.video.miclier-doku?sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%2Fplugin.video.miclier-doku%2Fresources%2Ffanart.jpg%26meta%3Dlabel%253D%25255BCOLORgreen%25255DMICLIER%25255B%25252FCOLOR%25255D-DOKU%26desc%3DDoku+Kan%C3%A4le+auf+Youtube+Terra+X%2CZDF+Histroy%2CArte%2CN24+usw+.%26_options_sf",icon2)
    #addDir("STUBE.RADIO","plugin://plugin.audio.stubegothic.radio",icon9)
    #addDir("[B][COLOR black]6[/COLOR] [COLOR white] FilmPalast[/COLOR][/B]","plugin://plugin.video.filmpalast_to",icon4)
    #addDir("[B][COLOR black]7[/COLOR] [COLOR blue] DDL.ME[/COLOR][/B]","plugin://plugin.video.ddl.me",icon5)
    #addDir("[B][COLOR black]8[/COLOR] [COLOR blue] Netzkino[/COLOR][/B]","plugin://plugin.video.netzkino_de",icon6)

   

    xbmcplugin.endOfDirectory(pluginhandle)
    
    
    
def addDir(name,url,iconimage):
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image',iconimage)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    return ok


def translation(id):
    return addon.getLocalizedString(id).encode('utf-8')


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

index()
