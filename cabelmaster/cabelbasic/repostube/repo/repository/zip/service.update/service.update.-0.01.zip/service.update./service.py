#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc
import os
import urllib
import xbmcgui

try:
    home_path = xbmc.translatePath('special://home/addons/version').decode('utf-8')
    try:
        with open(home_path, 'r') as g:
            versionhome = g.read()
    except:
        versionhome = '0'
    url = 'http://stubebox.stube.org/wizard/stubeboxv4/version'
    url1 = urllib.urlopen(url)
    versionurl = url1.read()

    if versionhome < versionurl:
        dialog = xbmcgui.Dialog()
        dialog.ok('STUBE.BOXv4 UPDATE INFO','EIN UPDATE IST VERFÜGBAR.','In den Einstellungen kannst du das Update herunterladen und installieren.','Viel Spass wünscht euch TEAM.STUBE')
except:
    pass