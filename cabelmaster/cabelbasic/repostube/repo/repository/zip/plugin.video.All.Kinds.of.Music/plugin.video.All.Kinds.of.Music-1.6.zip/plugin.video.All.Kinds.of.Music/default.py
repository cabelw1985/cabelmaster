#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import plugintools
import xbmc,xbmcaddon
import base64
import hashlib
from addon.common.addon import Addon

addonID = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PL3-sRm8xAzY89yb_OB-QtcCukQfFe864A"
YOUTUBE_CHANNEL_ID2 = "PLB5axqo_BYe1JqK7mXkjhx-4p_qiAw-5I"
YOUTUBE_CHANNEL_ID3 = "PLUarU1HDBmlwebnr2ynTGDdMxKJEDWNnN"
YOUTUBE_CHANNEL_ID4 = "PLD7SPvDoEddZUrho5ynsBfaI7nqhaNN5c"
YOUTUBE_CHANNEL_ID5 = "PL3-sRm8xAzY-YDhgZbycXLPnsue_mhU6B"
YOUTUBE_CHANNEL_ID6 = "PLsGK3aH9-P9krMatVVQwTuraacMknlAeB"
YOUTUBE_CHANNEL_ID7 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"
YOUTUBE_CHANNEL_ID8 = "PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo"
YOUTUBE_CHANNEL_ID9 = "PLsGK3aH9-P9nqEH-M-TKEnAcBNxhq1ljq"
YOUTUBE_CHANNEL_ID10 = "PLWlTX25IDqIwqowTsJmGhqxUWU_6qgG1W"
YOUTUBE_CHANNEL_ID11 = "PL6Go6XFhidEAH6LrK-RKxR5xwhdZ0g4vm"
YOUTUBE_CHANNEL_ID12 = "PLDIoUOhQQPlWvtxdeVTG3i7-SlSN0jfWj"
YOUTUBE_CHANNEL_ID13 = "PLxhnpe8pN3TlDGk0xqmLejhKU8Yi_I-fE"
YOUTUBE_CHANNEL_ID14 = "PL39z-AAkkats9VE4V8gdQyIjqp21nao9p"
YOUTUBE_CHANNEL_ID15 = "PLVf3PXRSPQRarUyt_B_X7O1fm9mGpeqn4"
YOUTUBE_CHANNEL_ID16 = "PL7DA3D097D6FDBC02"
YOUTUBE_CHANNEL_ID17 = "PLGBuKfnErZlCZed3VIG70mQBHPH7tKJ6D"
YOUTUBE_CHANNEL_ID18 = "PLd5xnond3B5Q8RQpGlrlvZv0n4_hpvxNv"
YOUTUBE_CHANNEL_ID19 = "PL09eGQfW13QjtcB0nITNYP56g8OMKe0uc"
YOUTUBE_CHANNEL_ID20 = "PLs5nLtKbGBVOZBCzgXxcN9fyCz6sQ1fab"
YOUTUBE_CHANNEL_ID21 = "PLWUXmX2htJ7Nx2_luG8WAVEnShOW-lGal"
YOUTUBE_CHANNEL_ID22 = "PLQlc99hV-nkGWDaG-gJxwOfqp8jxyHaaQ"
YOUTUBE_CHANNEL_ID23 = "PL2D4A44B959D87893"
YOUTUBE_CHANNEL_ID24 = "PLQ1TuSoOt3w3aQr-obgpzr7EeeM_shwvp"
YOUTUBE_CHANNEL_ID25 = "PLoumn5BIsUDdTFSnx5fSfQHQbnFtAJ5D2"
YOUTUBE_CHANNEL_ID26 = "PLAB1BFD67033229B4"
YOUTUBE_CHANNEL_ID27 = "PL6BA2D5208E8EF161"
YOUTUBE_CHANNEL_ID28 = "PL4DpwjwvhozHu4cQH7VZAASvcEFF_Hioa"
YOUTUBE_CHANNEL_ID29 = "PLb2aZl2AJg_VpTIQennzYzQVrA_fgRg7-"
YOUTUBE_CHANNEL_ID30 = ""
YOUTUBE_CHANNEL_ID31 = ""
YOUTUBE_CHANNEL_ID32 = ""
YOUTUBE_CHANNEL_ID33 = ""
YOUTUBE_CHANNEL_ID34 = ""
YOUTUBE_CHANNEL_ID35 = ""

def run():
    plugintools.log("Musik.run")
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("All Kinds of Musik-Videos.main_list"+repr(params))
    

    plugintools.add_item( 
        #action="", 
        title=" German TOP 100 Single Charts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
		thumbnail="https://i.ytimg.com/vi/8HSvsModtVg/maxresdefault.jpg",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" Top 100 Schlager Charts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://www.dropbox.com/s/3xccxez0psoq5ts/100%25%20Schlager.jpg?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" iTunes Top 100 US Hip Hop Rap Songs ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://www.dropbox.com/s/7hoo4nxilkpglc2/Itunes-logo-button.webp?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" Billboard Charts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="https://www.dropbox.com/s/699atmpi5hk8ikk/Billboard_Hot_100_logo.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" MTV Hits 2021 - Top 100 Charts Germany",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://www.dropbox.com/s/yjum89mceqv89ga/MTV.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" Tomorrowland,Parokaville,Defcon,Qlimax,Goa und Psytrance Festival",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail="https://www.dropbox.com/s/s2m12goh16786fi/a079c6502ef0e4996b2987a433320824.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" Best Pop Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="https://www.dropbox.com/s/hdtdkx76zqbqfx6/Pop%20Music.jpeg?dl=1",
        fanart="",
        folder=True )   
		
    plugintools.add_item(
        #action="",
        title=" Best Sounds of Summer",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="https://www.dropbox.com/s/d8lu4hp5ls039kv/Dance2.jpg?dl=1",
        fanart="",
        folder=True )		
		
    plugintools.add_item(
        #action="",
        title="  HD Musik Mix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail="https://www.dropbox.com/s/ykz8er3wlf6efit/Musik%20Mix.jpg?dl=1",
        fanart="",
        folder=True )		
    
    plugintools.add_item(
        #action="",
        title=" Now Dance Musik",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID10+"/",
        thumbnail="https://www.dropbox.com/s/pjqqrnssta5yroa/Dance5.jpg?dl=1",
        fanart="",
        folder=True )	
		
    plugintools.add_item(
        #action="",
        title=" Dance Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID11+"/",
        thumbnail="https://www.dropbox.com/s/wo0vkhrcskixm2w/Dance4.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" Vevo Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12+"/",
        thumbnail="https://www.dropbox.com/s/ms0yegta10lpf61/vevo.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" Deluxe Music ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID13+"/",
        thumbnail="https://www.dropbox.com/s/9xsk2bapwv3hsom/Deluxemusic.png?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" 2000's Party Music Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID14+"/",
        thumbnail="https://www.dropbox.com/s/xgk6j7bmchi017d/2000er%20Hits.jpg?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" Best Eurodance Songs of 90er",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID15+"/",
        thumbnail="https://www.dropbox.com/s/te37anwm4bbamjs/Eurodance.jpg?dl=1",
        fanart="",
        folder=True )	
		
    plugintools.add_item(
        #action="",
        title=" Greatest 90's Music Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID16+"/",
        thumbnail="https://www.dropbox.com/s/vipki2z661lgdd9/90s.jpg?dl=1",
        fanart="",
        folder=True )				

    plugintools.add_item(
        #action="",
        title=" Best of 80-90er Hits",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID17+"/",
        thumbnail="https://www.dropbox.com/s/rn4o15y43l1yi6i/Disco.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" Neue Deutsche Welle 80s",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID18+"/",
        thumbnail="https://www.dropbox.com/s/sbvo422jwyqyqq6/Neue%20deutsche%20Welle.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" Best of the 70er",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID19+"/",
        thumbnail="https://www.dropbox.com/s/rpqs3lxi40xyefe/Top%2070er.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" Greatest hits of the 60's",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID20+"/",
        thumbnail="https://www.dropbox.com/s/lb2am8ds67hxe46/60Ss.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" Heavy Metal",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID21+"/",
        thumbnail="https://www.dropbox.com/s/slxfdt1zhhgs9u3/Heavy%20Metal%20Rock.png?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" AC/DC",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID22+"/",
        thumbnail="https://www.dropbox.com/s/443tgokzg1tvuld/AC-DC.jpg?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" Metallica",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID23+"/",
        thumbnail="https://www.dropbox.com/s/q9asd2tl6tbhaem/Metallica.jpg?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" Best Rock Music ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID24+"/",
        thumbnail="https://www.dropbox.com/s/td2qklwc3vmixle/Rock%20Musik.jpg?dl=1",
        fanart="",
        folder=True )						
		
    plugintools.add_item( 
        title="Party Rock Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID25+"/",
        thumbnail="https://www.dropbox.com/s/4erh1o5pmrth0jt/Party%20Rock.jpg?dl=1",
        fanart="",
        folder=True )						
		
    plugintools.add_item( 
        title="70's Rock Musik",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID26+"/",
        thumbnail="https://www.dropbox.com/s/03xcbcu6lz6fbpx/70er%20Rock.png?dl=1",
        fanart="",
        folder=True )					
        
    plugintools.add_item( 
        title=" Love Songs",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID27+"/",
        thumbnail="https://www.dropbox.com/s/lzy3w97eh7qrxtb/Love%20Songs.jpg?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item( 
        title="Kuschelrock",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID28+"/",
        thumbnail="https://www.dropbox.com/s/lbi8rotsxord4ng/Kuschel%20Rock.jpg?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item( 
        title="Best Reggae Musik",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID29+"/",
        thumbnail="https://www.dropbox.com/s/0uqicooja8id4oi/This%20is%20reggea%20musik.png?dl=1",
        fanart="",
        folder=True )					   
			
run()
