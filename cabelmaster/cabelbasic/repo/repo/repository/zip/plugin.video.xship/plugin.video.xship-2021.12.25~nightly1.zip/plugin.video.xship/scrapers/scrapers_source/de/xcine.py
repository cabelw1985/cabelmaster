# -*- coding: UTF-8 -*-

#2022-01-02

import re
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser
from scrapers.modules.tools import cParser
from resources.lib.control import urljoin, quote_plus

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['xcine.me']
        self.base_link = 'https://xcine.me/'
        self.search_link = '/search?key=%s'
        self.search_api = self.base_link + '/search'
        self.get_link = 'movie/load-stream/%s/%s?'


    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        url = ''
        t = [cleantitle.get(i) for i in set(titles) if i]
        for title in titles:
            try:
                title = cleantitle.query(title)
                query = self.search_link % (quote_plus(title))
                query = urljoin(self.base_link, query)
                oRequest = cRequestHandler(query)
                #oRequest.addHeaderEntry('Referer', self.base_link + '/')
                #oRequest.addHeaderEntry('Host', self.domains[0])
                oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
                content = oRequest.request()
                searchResult = dom_parser.parse_dom(content, 'div', attrs={'class': 'group-film-small'})[0].content

                results = re.findall(r"href=\"(.*?)\" title=\"(.*?[^(]+).(\d{4})", searchResult, flags=re.DOTALL)

                if season == 0: #movie
                    years = ('%s' % str(year), '%s' % str(int(year) + 1), '%s' % str(int(year) - 1), '0')
                    for x in range(0, len(results)):
                        if results[x][2] in years:
                            title = cleantitle.get(results[x][1])
                            if any(i in title for i in t):
                                url = (results[x][0]) + '/deutsch'
                                break
                        if url: break

                else: #tvshow
                    for x in range(0, len(results)):
                        if not year == results[x][2]: continue
                        title = cleantitle.get(results[x][1])
                        if any(i in title for i in t):
                            if year == results[x][2]:
                                if "staffel0" + str(season) in title or "staffel" + str(season) in title:
                                    url = (results[x][0])
                                    break

                    for x in range(0, len(results)): # ohne 'year'
                        title = cleantitle.get(results[x][1])
                        if any(i in title for i in t):
                            if "staffel0" + str(season) in title or "staffel" + str(season) in title:
                                url = (results[x][0])
                                break

                    if url:
                        urlWithEpisode = url + '/folge-%s' % episode
                        url = urljoin(self.base_link, urlWithEpisode)
                        break
            except:
                 pass

        # print (url +'\n') # test only

        try:
            if not url: return sources
            #u'https://hdfilme.cc/the-poison-rose-dunkle-vergangenheit-14882-stream/deutsch'
            query = urljoin(self.base_link, url)
            oRequest = cRequestHandler(query)
            #oRequest.addHeaderEntry('Host', self.domains[0])
            oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
            sHtmlContent = oRequest.request()
            pattern = 'data-movie-id="(\d+).*?data-episode-id="(\d+)"'
            isMatch, aResult = cParser().parse(sHtmlContent, pattern)
            if isMatch:
                movie_id = aResult[0][0]
                episode_id = aResult[0][1]
            else: return sources

            #'movie/load-stream/14882/130355?'
            link = self.get_link % (movie_id,episode_id )
            link = urljoin(self.base_link, link)
            oRequest = cRequestHandler(link)
            oRequest.addHeaderEntry('Referer', urljoin(self.base_link, url))
            oRequest.addHeaderEntry('Host', self.domains[0])
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            moviesource = oRequest.request()
            if not moviesource: return sources

            #'https://load.hdfilme.ws/playlist/203829575d4e8d6602a69a746d7dacf4/203829575d4e8d6602a69a746d7dacf4.m3u8'
            isMatch, hUrl = cParser().parse(moviesource, 'urlVideo = "([^"]+)')
            if not isMatch: return sources
            m3u8_url =  hUrl[0]
            m3u8_base_url = m3u8_url.rpartition('/')[0]
            oRequest = cRequestHandler(m3u8_url)
            #oRequest.addHeaderEntry('Referer', urljoin(self.base_link, url))
            #oRequest.addHeaderEntry('Origin', self.domains[0])
            sHtmlContent = oRequest.request()
            pattern = 'RESOLUTION=([0-9,x]+)([^#]+)'
            isMatch, aResult = cParser().parse(sHtmlContent, pattern)
            if isMatch:
                for _quality, url in aResult:
                    if not 'http' in url: url = m3u8_base_url+'/'+ url

                    if "1080" in _quality or "1920" in _quality:
                        quality = "1080p"
                    elif "720" in _quality or "1280" in _quality:
                        quality = "720p"
                    else:
                        quality = 'SD'
                    sources.append({'source': 'XCINE.ME', 'quality': quality, 'language': 'de',
                                        'url': url, 'direct': True, 'debridonly': False, 'local': True})

            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0'
            return url + '|User-Agent=' + user_agent
        except:
            return


