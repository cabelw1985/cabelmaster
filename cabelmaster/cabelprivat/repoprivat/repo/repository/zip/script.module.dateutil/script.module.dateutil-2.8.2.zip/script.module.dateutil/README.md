script.module.dateutil
======================

Python dateutil library packed for Kodi.

See https://github.com/dateutil/dateutil
